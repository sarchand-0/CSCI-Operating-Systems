Round Robin Scheduling with CPU Class

This Python program implements the Round Robin (RR) scheduling algorithm using a class-based approach. The program uses a `CPU` class to represent each process, and the `rr` function calculates and displays the waiting time, turn-around time, and Gantt chart for the processes.

## Features:
- **Round Robin Scheduling:** The program implements the Round Robin scheduling algorithm to efficiently allocate CPU time among multiple processes.
- **Waiting Time Calculation:** Calculates the waiting time for each process.
- **Turn-Around Time Calculation:** Calculates the turn-around time for each process.
- **Gantt Chart Display:** Visualizes the execution of processes with a Gantt chart.
- **Average Waiting Time and Turn-Around Time:** Displays the average waiting time and average turn-around time for all processes.

## How to Use:

1. **Input:** Run the program, and it will prompt you to enter the number of processes, arrival time, and burst time for each process.
	In the Terminal in the file location :
    ```
    python RoundRobin.py
    ```

2. **Enter Details:** Input the details for each process, including arrival time and burst time.
Froe example:

    ```
    Enter number of processes: 3
    Enter details for process 1:
    Enter arrival time: 0
    Enter burst time: 10
    Enter details for process 2:
    Enter arrival time: 2
    Enter burst time: 5
    Enter details for process 3:
    Enter arrival time: 4
    Enter burst time: 8
    ```

3. **Time Quantum:** Input the time quantum when prompted.

    ```
    Enter time quantum: 2
    ```

4. **Output:** The program will display the Gantt chart, process ID, turn-around time, waiting time, and average times for all processes.

    ```
    Gantt Chart:
    | P1 [0-2] | P2 [2-4] | P3 [4-6] | P1 [6-8] | P2 [8-10] | P3 [10-12] | P1 [12-14] | P3 [14-16] |

    Process ID    Turnaround Time    Waiting Time
    1             16                 6
    2             14                 7
    3             18                 10

    Average Waiting Time: 7.666666666666667
    Average Turnaround Time: 16.0
