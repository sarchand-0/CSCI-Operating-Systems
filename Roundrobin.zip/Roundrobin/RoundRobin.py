class CPU:
    def __init__(self, processId=0, burst=0, arrival=0, priority=0):
        self.processId = processId
        self.burst = burst
        self.arrival = arrival
        self.priority = priority
def rr(cpu_list, num):
    tq = int(input("Enter time quantum: "))
    waiting_times = [0] * num
    turnaround_times = [0] * num
    time_passed = 0

    gantt_chart = ""

    cpu_list.sort(key=lambda cpu: cpu.arrival)
    remaining_burst_times = [cpu.burst for cpu in cpu_list]
    Done = [False] * num

    while not all(Done):
        for i in range(num):
            if remaining_burst_times[i] > 0:
                if remaining_burst_times[i] > tq:
                    gantt_chart += f"| P{cpu_list[i].processId} [{time_passed}-{time_passed + tq}] "
                    time_passed += tq
                    remaining_burst_times[i] -= tq
                else:
                    gantt_chart += f"| P{cpu_list[i].processId} [{time_passed}-{time_passed + remaining_burst_times[i]}] "
                    time_passed += remaining_burst_times[i]
                    waiting_times[i] = time_passed - cpu_list[i].burst
                    turnaround_times[i] = time_passed - cpu_list[i].arrival
                    remaining_burst_times[i] = 0
                    Done[i] = True


    print("\nGantt Chart:\n" + gantt_chart)
    print("\nProcess ID\tTurnaround Time\tWaiting Time")
    for i in range(num):
        print(f"{cpu_list[i].processId}\t\t{turnaround_times[i]}\t\t{waiting_times[i]}")

    avg_waiting_time = sum(waiting_times) / num
    avg_turnaround_time = sum(turnaround_times) / num
    print(f"\nAverage Waiting Time: {avg_waiting_time}")
    print(f"Average Turnaround Time: {avg_turnaround_time}")

if __name__ == "__main__":
    num = int(input("Enter number of processes: "))
    cpu_list = [CPU() for _ in range(num)]
    for i in range(num):
        print(f"Enter details for process {i+1}:")
        arrival = int(input("Enter arrival time: "))
        burst = int(input("Enter burst time: "))
        cpu_list[i].processId = i+1
        cpu_list[i].arrival = arrival
        cpu_list[i].burst = burst

    rr(cpu_list, num)
