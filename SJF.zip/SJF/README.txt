# Shortest Job First (SJF) Scheduling Algorithm

## Overview

This program implements the Shortest Job First (SJF) scheduling algorithm. SJF is a non-preemptive scheduling algorithm that selects the process with the shortest burst time first for execution. The program takes user input for process details, such as Process ID, Arrival Time, and Burst Time, and then schedules the processes using the SJF algorithm. Additionally, it calculates and displays the Average Turnaround Time and Average Waiting Time for the scheduled processes. Finally, a Gantt chart is generated to visualize the schedule.

## Algorithms Used

### 1. Shortest Job First (SJF) Scheduling Algorithm

- The main scheduling algorithm is SJF, which sorts the processes based on their arrival times and burst times to determine the execution order.

### 2. Gantt Chart Generation

- The Gantt chart is generated to visually represent the scheduled processes and their execution timeline.

## How to Use

1. Run the program.
2. Enter the number of processes when prompted.
3. For each process, enter the Process ID, Arrival Time, and Burst Time as instructed.
4. The program will execute the SJF algorithm, calculate performance metrics, and display the schedule along with Average Turnaround Time and Average Waiting Time.
5. The Gantt chart will be generated and displayed to visualize the process schedule.

## Class and Methods

### Class: SJF

#### Method: \_\_init\_\_

- Initializes an instance of the SJF class.

#### Method: processData

- Takes user input for the number of processes and their details.
- Calls the schedulingProcess method to execute the SJF algorithm.

#### Method: schedulingProcess

- Implements the SJF scheduling algorithm.
- Calculates start and exit times for each process.
- Calls calculateTurnaroundTime and calculateWaitingTime methods.
- Calls printData method to display the results.

#### Method: calculateTurnaroundTime

- Calculates the turnaround time for each process and returns the average turnaround time.

#### Method: calculateWaitingTime

- Calculates the waiting time for each process and returns the average waiting time.

#### Method: printData

- Displays the details of each process, including completion time, turnaround time, and waiting time.
- Prints the Average Turnaround Time and Average Waiting Time.

#### Method: generateGanttChart

- Sorts processes based on their completion time.
- Generates and displays the Gantt chart to visualize the process schedule.

### Main Execution

- Takes user input for the number of processes.
- Creates an instance of the SJF class.
- Calls the processData method to execute the program.

## Example

```
$ python SJF.py
Enter number of processes: 4
Enter Process ID: 1
Enter Arrival Time for Process 1: 0
Enter Burst Time for Process 1: 5
Enter Process ID: 2
Enter Arrival Time for Process 2: 2
Enter Burst Time for Process 2: 3
Enter Process ID: 3
Enter Arrival Time for Process 3: 3
Enter Burst Time for Process 3: 8
Enter Process ID: 4
Enter Arrival Time for Process 4: 5
Enter Burst Time for Process 4: 2

...

Gantt Chart:
| P1 [0, 5] | P2 [5, 8] | P4 [8, 10] | P3 [10, 18] |
